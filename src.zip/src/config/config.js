/* File: config.js */
module.exports = {
    database: {
        host: 'localhost',
        port: 3306,
        user: '<database user>',
        password: '<password>',
        database: '<database name>'
    }
};
